su -c "sysctl -w kernel.randomize_va_space=0"

