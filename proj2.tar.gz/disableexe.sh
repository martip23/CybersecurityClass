su -c "sysctl -w kernel.exec-shield=0"

