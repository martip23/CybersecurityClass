su -c "sysctl -w kernel.exec-shield=2"

